# Overview

This is a Solana SPL token creation application built with React/TypeScript frontend and Express.js backend. The application allows users to connect their Solana wallets and create custom SPL tokens with configurable parameters like name, symbol, decimals, and initial supply. It features a modern UI built with shadcn/ui components and provides real-time feedback during token creation processes.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built using modern React with TypeScript and follows a component-based architecture:

- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with a dark theme configuration and custom CSS variables
- **State Management**: React Query (TanStack Query) for server state and React hooks for local state
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod schema validation for type-safe form validation

## Backend Architecture

The backend follows a RESTful API design with Express.js:

- **Framework**: Express.js with TypeScript
- **Development Setup**: Uses tsx for TypeScript execution in development and esbuild for production builds
- **API Structure**: RESTful endpoints under `/api` prefix with proper error handling middleware
- **Storage**: Currently using in-memory storage (MemStorage class) for development, with an interface designed for easy database integration
- **Validation**: Zod schemas shared between frontend and backend for consistent validation

## Data Storage Solutions

The application uses a flexible storage architecture:

- **Current Implementation**: In-memory storage for development and testing
- **Database Ready**: Drizzle ORM configured with PostgreSQL schema definitions
- **Schema Design**: Tokens table with fields for name, symbol, decimals, supply, mint address, and wallet association
- **Migration Support**: Drizzle kit configured for database migrations

## Authentication and Authorization Mechanisms

The application uses Solana wallet-based authentication:

- **Wallet Integration**: Support for multiple Solana wallets (Phantom, Solflare) through browser extensions
- **Wallet Context**: React context provider managing wallet connection state and public key
- **Session Management**: Wallet addresses are used to identify users and associate created tokens
- **Authorization**: Token creation requires connected wallet, with wallet address embedded in token records

## External Dependencies

### Solana Integration
- **@solana/web3.js**: Core Solana blockchain interaction library
- **@solana/spl-token**: SPL token program integration for token creation and management
- **@neondatabase/serverless**: PostgreSQL database adapter for serverless environments

### UI and Styling
- **@radix-ui/***: Comprehensive set of unstyled, accessible UI primitives
- **tailwindcss**: Utility-first CSS framework with custom design system
- **lucide-react**: Icon library for consistent iconography
- **class-variance-authority**: Utility for creating type-safe component variants

### Development and Build Tools
- **vite**: Fast build tool and development server
- **drizzle-orm**: Type-safe ORM with PostgreSQL support
- **tsx**: TypeScript execution engine for development
- **esbuild**: Fast JavaScript bundler for production builds

### Form and Data Handling
- **react-hook-form**: Performant forms library with minimal re-renders
- **@hookform/resolvers**: Integration layer for validation libraries
- **zod**: TypeScript-first schema validation library
- **@tanstack/react-query**: Server state management and caching solution

The architecture separates concerns effectively with shared TypeScript schemas between frontend and backend, ensuring type safety across the entire application stack. The wallet-based authentication model aligns with Web3 patterns, while the modular storage interface allows for easy scaling from development to production databases.