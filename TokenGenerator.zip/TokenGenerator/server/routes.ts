import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { solanaService } from "./services/solana";
import { createTokenSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create token endpoint
  app.post("/api/tokens", async (req, res) => {
    try {
      const validation = createTokenSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid token parameters",
          errors: validation.error.errors
        });
      }

      const tokenData = validation.data;
      
      // Extract wallet address from request (in a real app, this would come from authentication)
      const walletAddress = req.body.walletAddress;
      if (!walletAddress) {
        return res.status(400).json({ message: "Wallet address is required" });
      }

      // Create token on Solana
      const result = await solanaService.createToken({
        ...tokenData,
        payerPublicKey: walletAddress
      });

      // Store token in database
      const token = await storage.createToken({
        ...tokenData,
        mintAddress: result.mintAddress,
        signature: result.signature,
        walletAddress
      });

      res.json(token);
    } catch (error) {
      console.error('Token creation error:', error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to create token"
      });
    }
  });

  // Get tokens by wallet
  app.get("/api/tokens/wallet/:address", async (req, res) => {
    try {
      const tokens = await storage.getTokensByWallet(req.params.address);
      res.json(tokens);
    } catch (error) {
      console.error('Error fetching tokens:', error);
      res.status(500).json({ message: "Failed to fetch tokens" });
    }
  });

  // Get recent tokens
  app.get("/api/tokens/recent", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const tokens = await storage.getRecentTokens(limit);
      res.json(tokens);
    } catch (error) {
      console.error('Error fetching recent tokens:', error);
      res.status(500).json({ message: "Failed to fetch recent tokens" });
    }
  });

  // Get network info
  app.get("/api/network", async (req, res) => {
    try {
      const networkInfo = await solanaService.getNetworkInfo();
      res.json(networkInfo);
    } catch (error) {
      console.error('Error fetching network info:', error);
      res.status(500).json({ message: "Failed to fetch network info" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
