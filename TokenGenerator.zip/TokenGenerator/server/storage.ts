import { type Token, type InsertToken } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getToken(id: string): Promise<Token | undefined>;
  getTokensByWallet(walletAddress: string): Promise<Token[]>;
  createToken(token: InsertToken & { mintAddress: string; signature: string; walletAddress: string }): Promise<Token>;
  getRecentTokens(limit?: number): Promise<Token[]>;
}

export class MemStorage implements IStorage {
  private tokens: Map<string, Token>;

  constructor() {
    this.tokens = new Map();
  }

  async getToken(id: string): Promise<Token | undefined> {
    return this.tokens.get(id);
  }

  async getTokensByWallet(walletAddress: string): Promise<Token[]> {
    return Array.from(this.tokens.values()).filter(
      (token) => token.walletAddress === walletAddress
    );
  }

  async createToken(insertToken: InsertToken & { mintAddress: string; signature: string; walletAddress: string }): Promise<Token> {
    const id = randomUUID();
    const token: Token = { 
      ...insertToken,
      decimals: insertToken.decimals ?? 9,
      metadataUri: insertToken.metadataUri ?? null,
      id,
      createdAt: new Date()
    };
    this.tokens.set(id, token);
    return token;
  }

  async getRecentTokens(limit = 10): Promise<Token[]> {
    const allTokens = Array.from(this.tokens.values());
    return allTokens
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0))
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
