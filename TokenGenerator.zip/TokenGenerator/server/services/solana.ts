import { Connection, Keypair, PublicKey, Transaction } from '@solana/web3.js';
import { createMint, getOrCreateAssociatedTokenAccount, mintTo } from '@solana/spl-token';

export interface TokenCreationParams {
  name: string;
  symbol: string;
  decimals: number;
  initialSupply: string;
  metadataUri?: string;
  payerPublicKey: string;
}

export interface TokenCreationResult {
  mintAddress: string;
  signature: string;
}

export class SolanaTokenService {
  private connection: Connection;
  private payer: Keypair;

  constructor() {
    // Use environment variables for RPC URL and payer keypair
    const rpcUrl = process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com';
    this.connection = new Connection(rpcUrl, 'confirmed');
    
    // In production, you would use a proper keypair management system
    // For now, we'll generate a new keypair (this would need proper funding)
    this.payer = Keypair.generate();
  }

  async createToken(params: TokenCreationParams): Promise<TokenCreationResult> {
    try {
      const payerPublicKey = new PublicKey(params.payerPublicKey);
      
      // Create the mint
      const mint = await createMint(
        this.connection,
        this.payer, // payer
        payerPublicKey, // mint authority
        null, // freeze authority (null means no freeze authority)
        params.decimals // decimals
      );

      // Get or create associated token account for the payer
      const tokenAccount = await getOrCreateAssociatedTokenAccount(
        this.connection,
        this.payer,
        mint,
        payerPublicKey
      );

      // Mint initial supply to the token account
      const mintSignature = await mintTo(
        this.connection,
        this.payer,
        mint,
        tokenAccount.address,
        payerPublicKey,
        BigInt(params.initialSupply) * BigInt(10 ** params.decimals)
      );

      return {
        mintAddress: mint.toBase58(),
        signature: mintSignature
      };
    } catch (error) {
      console.error('Error creating token:', error);
      throw new Error(`Failed to create token: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getNetworkInfo() {
    try {
      const slot = await this.connection.getSlot();
      const blockHeight = await this.connection.getBlockHeight();
      
      return {
        slot,
        blockHeight,
        network: 'mainnet-beta'
      };
    } catch (error) {
      console.error('Error getting network info:', error);
      return {
        slot: 0,
        blockHeight: 0,
        network: 'unknown'
      };
    }
  }
}

export const solanaService = new SolanaTokenService();
