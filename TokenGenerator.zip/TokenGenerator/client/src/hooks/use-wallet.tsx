import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { PublicKey } from '@solana/web3.js';
import { getWalletAdapters, type WalletAdapter } from '@/lib/solana';
import { useToast } from '@/hooks/use-toast';

interface WalletContextType {
  wallet: WalletAdapter | null;
  publicKey: PublicKey | null;
  connected: boolean;
  connecting: boolean;
  connect: (walletName: string) => Promise<void>;
  disconnect: () => Promise<void>;
  availableWallets: WalletAdapter[];
}

const WalletContext = createContext<WalletContextType | null>(null);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletAdapter | null>(null);
  const [publicKey, setPublicKey] = useState<PublicKey | null>(null);
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [availableWallets] = useState(getWalletAdapters());
  const { toast } = useToast();

  useEffect(() => {
    // Check if wallet was previously connected
    const savedWalletName = localStorage.getItem('selectedWallet');
    if (savedWalletName) {
      const savedWallet = availableWallets.find(w => w.name === savedWalletName);
      if (savedWallet) {
        connect(savedWalletName).catch(() => {
          localStorage.removeItem('selectedWallet');
        });
      }
    }
  }, []);

  const connect = async (walletName: string) => {
    setConnecting(true);
    try {
      const selectedWallet = availableWallets.find(w => w.name === walletName);
      if (!selectedWallet) {
        throw new Error('Wallet not found');
      }

      const { publicKey: walletPublicKey } = await selectedWallet.connect();
      
      setWallet(selectedWallet);
      setPublicKey(walletPublicKey);
      setConnected(true);
      localStorage.setItem('selectedWallet', walletName);
      
      toast({
        title: "Wallet Connected",
        description: `Connected to ${walletName}`,
      });
    } catch (error) {
      console.error('Wallet connection failed:', error);
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Failed to connect wallet",
        variant: "destructive",
      });
    } finally {
      setConnecting(false);
    }
  };

  const disconnect = async () => {
    try {
      if (wallet) {
        await wallet.disconnect();
      }
      
      setWallet(null);
      setPublicKey(null);
      setConnected(false);
      localStorage.removeItem('selectedWallet');
      
      toast({
        title: "Wallet Disconnected",
        description: "Wallet has been disconnected",
      });
    } catch (error) {
      console.error('Wallet disconnection failed:', error);
    }
  };

  return (
    <WalletContext.Provider value={{
      wallet,
      publicKey,
      connected,
      connecting,
      connect,
      disconnect,
      availableWallets
    }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}
