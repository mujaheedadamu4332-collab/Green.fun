import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { createTokenSchema, type CreateToken, type Token } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useWallet } from '@/hooks/use-wallet';
import { useToast } from '@/hooks/use-toast';
import { Info, Loader2 } from 'lucide-react';

interface TokenCreationFormProps {
  onSuccess: (token: Token) => void;
  onError: (error: string) => void;
}

export function TokenCreationForm({ onSuccess, onError }: TokenCreationFormProps) {
  const { publicKey, connected } = useWallet();
  const { toast } = useToast();

  const form = useForm<CreateToken>({
    resolver: zodResolver(createTokenSchema),
    defaultValues: {
      name: '',
      symbol: '',
      decimals: 9,
      initialSupply: '',
      metadataUri: '',
    },
  });

  const createTokenMutation = useMutation({
    mutationFn: async (data: CreateToken) => {
      if (!publicKey) throw new Error('Wallet not connected');
      
      const response = await apiRequest('POST', '/api/tokens', {
        ...data,
        walletAddress: publicKey.toBase58(),
      });
      return response.json();
    },
    onSuccess: (token: Token) => {
      const queryClient = useQueryClient();
      queryClient.invalidateQueries({ queryKey: ['/api/tokens'] });
      toast({
        title: "Token Created!",
        description: `${token.name} (${token.symbol}) has been created successfully.`,
      });
      onSuccess(token);
      form.reset();
    },
    onError: (error: Error) => {
      console.error('Token creation failed:', error);
      const errorMessage = error.message || 'Failed to create token. Please try again.';
      toast({
        title: "Creation Failed",
        description: errorMessage,
        variant: "destructive",
      });
      onError(errorMessage);
    },
  });

  const onSubmit = (data: CreateToken) => {
    if (!connected) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet first",
        variant: "destructive",
      });
      return;
    }
    createTokenMutation.mutate(data);
  };

  return (
    <div className="lg:col-span-2">
      <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground mb-2">Create Your Token</h2>
          <p className="text-muted-foreground">Fill in the details below to create your SPL token on Solana</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Token Name */}
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center space-x-1">
                    <span>Token Name</span>
                    <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="My Awesome Token" 
                      {...field}
                      data-testid="input-token-name"
                    />
                  </FormControl>
                  <FormDescription>
                    The display name for your token
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Token Symbol */}
            <FormField
              control={form.control}
              name="symbol"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="flex items-center space-x-1">
                    <span>Token Symbol</span>
                    <span className="text-destructive">*</span>
                  </FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="MAT" 
                      maxLength={10}
                      {...field}
                      onChange={(e) => field.onChange(e.target.value.toUpperCase())}
                      data-testid="input-token-symbol"
                    />
                  </FormControl>
                  <FormDescription>
                    Short identifier (e.g., SOL, USDC)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Decimals */}
              <FormField
                control={form.control}
                name="decimals"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center space-x-1">
                      <span>Decimals</span>
                      <span className="text-destructive">*</span>
                    </FormLabel>
                    <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value.toString()}>
                      <FormControl>
                        <SelectTrigger data-testid="select-decimals">
                          <SelectValue placeholder="Select decimals" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="6">6</SelectItem>
                        <SelectItem value="8">8</SelectItem>
                        <SelectItem value="9">9 (Standard)</SelectItem>
                        <SelectItem value="18">18</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Initial Supply */}
              <FormField
                control={form.control}
                name="initialSupply"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center space-x-1">
                      <span>Initial Supply</span>
                      <span className="text-destructive">*</span>
                    </FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="1000000" 
                        min="1"
                        {...field}
                        data-testid="input-initial-supply"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Metadata URI */}
            <FormField
              control={form.control}
              name="metadataUri"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Metadata URI</FormLabel>
                  <FormControl>
                    <Input 
                      type="url" 
                      placeholder="https://example.com/metadata.json" 
                      {...field}
                      data-testid="input-metadata-uri"
                    />
                  </FormControl>
                  <FormDescription>
                    Optional: Link to JSON metadata for your token
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Creation Fee Info */}
            <div className="bg-muted/50 border border-border rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <Info className="w-5 h-5 text-primary mt-0.5" />
                <div>
                  <h4 className="font-medium text-foreground">Transaction Fee</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Creating a token requires approximately <span className="font-mono text-foreground">~0.002 SOL</span> for transaction fees and rent.
                  </p>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <Button 
              type="submit" 
              className="w-full wallet-button text-primary-foreground py-4 rounded-lg font-semibold hover:shadow-lg transition-all duration-200 flex items-center justify-center space-x-2"
              disabled={createTokenMutation.isPending || !connected}
              data-testid="button-create-token"
            >
              {createTokenMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Creating Token...</span>
                </>
              ) : (
                <span>Create Token</span>
              )}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
