import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Copy, Plus, CheckCircle, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Token } from '@shared/schema';

interface TransactionResultsProps {
  token: Token;
  onCreateAnother: () => void;
  isVisible: boolean;
}

export function TransactionResults({ token, onCreateAnother, isVisible }: TransactionResultsProps) {
  const { toast } = useToast();

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied!",
        description: `${label} copied to clipboard`,
      });
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  if (!isVisible) return null;

  return (
    <div className="mt-8 slide-up" data-testid="transaction-results">
      <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-2">Token Created Successfully!</h2>
          <p className="text-muted-foreground">Your SPL token has been deployed to the Solana blockchain</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Token Mint Address */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-foreground">Token Mint Address</label>
            <div className="flex items-center space-x-2 bg-muted/50 border border-border rounded-lg p-3">
              <Input 
                readOnly 
                value={token.mintAddress}
                className="flex-1 bg-transparent text-sm font-mono text-foreground border-none focus:ring-0 p-0"
                data-testid="input-mint-address"
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(token.mintAddress, 'Mint address')}
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-copy-mint"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Transaction Signature */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-foreground">Transaction Signature</label>
            <div className="flex items-center space-x-2 bg-muted/50 border border-border rounded-lg p-3">
              <Input 
                readOnly 
                value={token.signature}
                className="flex-1 bg-transparent text-sm font-mono text-foreground border-none focus:ring-0 p-0"
                data-testid="input-transaction-signature"
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(token.signature, 'Transaction signature')}
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-copy-signature"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-center space-x-4 mt-6">
          <Button
            variant="link"
            asChild
            className="text-primary hover:text-primary/80 transition-colors"
            data-testid="link-explorer"
          >
            <a 
              href={`https://explorer.solana.com/tx/${token.signature}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2"
            >
              <ExternalLink className="w-4 h-4" />
              <span>View on Solana Explorer</span>
            </a>
          </Button>
          <Button 
            onClick={onCreateAnother}
            className="wallet-button text-primary-foreground px-6 py-2 rounded-lg hover:shadow-lg transition-all duration-200 flex items-center space-x-2"
            data-testid="button-create-another"
          >
            <Plus className="w-4 h-4" />
            <span>Create Another Token</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
