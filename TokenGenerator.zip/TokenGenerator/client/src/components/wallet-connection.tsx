import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useWallet } from '@/hooks/use-wallet';
import { formatAddress } from '@/lib/solana';
import { Wallet, X, ExternalLink } from 'lucide-react';

export function WalletConnection() {
  const { wallet, publicKey, connected, connecting, connect, disconnect, availableWallets } = useWallet();
  const [showWalletDialog, setShowWalletDialog] = useState(false);

  const handleWalletSelect = async (walletName: string) => {
    await connect(walletName);
    setShowWalletDialog(false);
  };

  if (connected && wallet && publicKey) {
    return (
      <div className="bg-secondary/50 border border-border rounded-lg px-4 py-2" data-testid="wallet-connected">
        <div className="flex items-center space-x-3">
          <div className="w-2 h-2 bg-green-500 rounded-full pulse-effect"></div>
          <div>
            <p className="text-sm font-medium" data-testid="wallet-name">{wallet.name}</p>
            <p className="text-xs text-muted-foreground font-mono" data-testid="wallet-address">
              {formatAddress(publicKey.toBase58())}
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={disconnect}
            className="text-muted-foreground hover:text-foreground"
            data-testid="button-disconnect"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <Dialog open={showWalletDialog} onOpenChange={setShowWalletDialog}>
      <DialogTrigger asChild>
        <Button
          className="wallet-button text-primary-foreground px-6 py-2 rounded-lg font-medium hover:shadow-lg transition-all duration-200 flex items-center space-x-2"
          disabled={connecting}
          data-testid="button-connect-wallet"
        >
          <Wallet className="w-5 h-5" />
          <span>{connecting ? 'Connecting...' : 'Connect Wallet'}</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Select a Wallet</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {availableWallets.map((walletAdapter) => (
            <Button
              key={walletAdapter.name}
              variant="outline"
              className="w-full justify-between"
              onClick={() => handleWalletSelect(walletAdapter.name)}
              data-testid={`button-select-${walletAdapter.name.toLowerCase()}`}
            >
              <div className="flex items-center space-x-3">
                <span className="text-lg">{walletAdapter.icon}</span>
                <span>{walletAdapter.name}</span>
              </div>
              <ExternalLink className="w-4 h-4" />
            </Button>
          ))}
        </div>
        <p className="text-xs text-muted-foreground text-center">
          Don't have a wallet? Install one from the options above.
        </p>
      </DialogContent>
    </Dialog>
  );
}
