import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';

interface ErrorDisplayProps {
  message: string;
  onRetry: () => void;
  isVisible: boolean;
}

export function ErrorDisplay({ message, onRetry, isVisible }: ErrorDisplayProps) {
  if (!isVisible) return null;

  return (
    <div className="mt-8 slide-up" data-testid="error-display">
      <div className="bg-destructive/10 border border-destructive/50 rounded-xl p-6">
        <div className="flex items-start space-x-4">
          <div className="w-10 h-10 bg-destructive/20 rounded-full flex items-center justify-center flex-shrink-0">
            <AlertTriangle className="w-5 h-5 text-destructive" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-destructive mb-2">Transaction Failed</h3>
            <p className="text-sm text-destructive/80 mb-4" data-testid="text-error-message">
              {message}
            </p>
            <Button 
              onClick={onRetry}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-colors text-sm font-medium"
              data-testid="button-retry"
            >
              Try Again
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
