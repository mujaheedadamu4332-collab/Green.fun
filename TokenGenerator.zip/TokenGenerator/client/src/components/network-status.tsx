import { useQuery } from '@tanstack/react-query';
import { Activity } from 'lucide-react';

interface NetworkInfo {
  slot: number;
  blockHeight: number;
  network: string;
}

export function NetworkStatus() {
  const { data: networkInfo } = useQuery<NetworkInfo>({
    queryKey: ['/api/network'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      <h3 className="font-semibold text-foreground mb-4 flex items-center space-x-2">
        <Activity className="w-5 h-5 text-primary" />
        <span>Network Status</span>
      </h3>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Network</span>
          <span className="text-sm font-medium text-foreground">
            {networkInfo?.network || 'mainnet-beta'}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Status</span>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-500 rounded-full pulse-effect"></div>
            <span className="text-sm font-medium text-green-500">Connected</span>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Block Height</span>
          <span className="text-sm font-mono text-foreground" data-testid="text-block-height">
            {networkInfo?.blockHeight?.toLocaleString() || '---'}
          </span>
        </div>
      </div>
    </div>
  );
}
