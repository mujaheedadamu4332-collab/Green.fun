import { Connection, PublicKey } from '@solana/web3.js';

export interface WalletAdapter {
  name: string;
  icon: string;
  url: string;
  connect(): Promise<{ publicKey: PublicKey }>;
  disconnect(): Promise<void>;
  signTransaction?(transaction: any): Promise<any>;
  signAllTransactions?(transactions: any[]): Promise<any[]>;
}

// Mock wallet adapters for different wallets
export const getWalletAdapters = (): WalletAdapter[] => [
  {
    name: 'Phantom',
    icon: '👻',
    url: 'https://phantom.app/',
    async connect() {
      if (typeof window !== 'undefined' && (window as any).solana?.isPhantom) {
        const response = await (window as any).solana.connect();
        return { publicKey: new PublicKey(response.publicKey.toString()) };
      }
      throw new Error('Phantom wallet not found');
    },
    async disconnect() {
      if (typeof window !== 'undefined' && (window as any).solana?.isPhantom) {
        await (window as any).solana.disconnect();
      }
    }
  },
  {
    name: 'Solflare',
    icon: '☀️',
    url: 'https://solflare.com/',
    async connect() {
      if (typeof window !== 'undefined' && (window as any).solflare) {
        const response = await (window as any).solflare.connect();
        return { publicKey: new PublicKey(response.publicKey.toString()) };
      }
      throw new Error('Solflare wallet not found');
    },
    async disconnect() {
      if (typeof window !== 'undefined' && (window as any).solflare) {
        await (window as any).solflare.disconnect();
      }
    }
  }
];

export const getSolanaConnection = () => {
  const rpcUrl = import.meta.env.VITE_SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com';
  return new Connection(rpcUrl, 'confirmed');
};

export const formatAddress = (address: string, length = 8): string => {
  if (address.length <= length) return address;
  return `${address.slice(0, length / 2)}...${address.slice(-length / 2)}`;
};
