import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { TokenCreationForm } from '@/components/token-creation-form';
import { TransactionResults } from '@/components/transaction-results';
import { ErrorDisplay } from '@/components/error-display';
import { LoadingOverlay } from '@/components/loading-overlay';
import { NetworkStatus } from '@/components/network-status';
import { WalletConnection } from '@/components/wallet-connection';
import { useWallet } from '@/hooks/use-wallet';
import { CheckCircle, HelpCircle, Clock } from 'lucide-react';
import type { Token } from '@shared/schema';

export default function Home() {
  const { connected } = useWallet();
  const [createdToken, setCreatedToken] = useState<Token | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState('');

  const { data: recentTokens } = useQuery<Token[]>({
    queryKey: ['/api/tokens/recent'],
    enabled: true,
  });

  const handleTokenCreationStart = () => {
    setIsCreating(true);
    setLoadingMessage('Preparing transaction...');
    setError(null);
    setCreatedToken(null);
  };

  const handleTokenCreationSuccess = (token: Token) => {
    setCreatedToken(token);
    setIsCreating(false);
    setError(null);
  };

  const handleTokenCreationError = (errorMessage: string) => {
    setError(errorMessage);
    setIsCreating(false);
    setCreatedToken(null);
  };

  const handleCreateAnother = () => {
    setCreatedToken(null);
    setError(null);
  };

  const handleRetry = () => {
    setError(null);
    // The form will handle the retry logic
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans antialiased">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Solana Token Creator</h1>
                <p className="text-sm text-muted-foreground">Create SPL tokens on Solana</p>
              </div>
            </div>
            
            <WalletConnection />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Token Creation Form */}
          <TokenCreationForm
            onSuccess={handleTokenCreationSuccess}
            onError={handleTokenCreationError}
          />

          {/* Sidebar */}
          <div className="space-y-6">
            
            {/* Network Status */}
            <NetworkStatus />

            {/* Quick Guide */}
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-semibold text-foreground mb-4 flex items-center space-x-2">
                <HelpCircle className="w-5 h-5 text-primary" />
                <span>Quick Guide</span>
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-primary/20 text-primary rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">1</div>
                  <p className="text-muted-foreground">Connect your Solana wallet (Phantom, Solflare, etc.)</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-primary/20 text-primary rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">2</div>
                  <p className="text-muted-foreground">Fill in your token details and parameters</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-primary/20 text-primary rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">3</div>
                  <p className="text-muted-foreground">Review and confirm the transaction</p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-primary/20 text-primary rounded-full flex items-center justify-center text-xs font-semibold flex-shrink-0 mt-0.5">4</div>
                  <p className="text-muted-foreground">Get your token mint address and share it</p>
                </div>
              </div>
            </div>

            {/* Recent Tokens */}
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="font-semibold text-foreground mb-4 flex items-center space-x-2">
                <Clock className="w-5 h-5 text-primary" />
                <span>Recent Creations</span>
              </h3>
              <div className="space-y-3">
                {recentTokens && recentTokens.length > 0 ? (
                  recentTokens.slice(0, 3).map((token) => (
                    <div key={token.id} className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                      <div className="w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                        <span className="text-xs font-semibold text-primary">
                          {token.symbol.slice(0, 2)}
                        </span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{token.name}</p>
                        <p className="text-xs text-muted-foreground font-mono truncate">
                          {token.mintAddress.slice(0, 8)}...{token.mintAddress.slice(-8)}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No tokens created yet
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Transaction Results */}
        {createdToken && (
          <TransactionResults
            token={createdToken}
            onCreateAnother={handleCreateAnother}
            isVisible={!!createdToken}
          />
        )}

        {/* Error Display */}
        {error && (
          <ErrorDisplay
            message={error}
            onRetry={handleRetry}
            isVisible={!!error}
          />
        )}
      </main>

      {/* Loading Overlay */}
      <LoadingOverlay
        isVisible={isCreating}
        message={loadingMessage}
      />
    </div>
  );
}
