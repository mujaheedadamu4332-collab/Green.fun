import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tokens = pgTable("tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  decimals: integer("decimals").notNull().default(9),
  initialSupply: text("initial_supply").notNull(),
  metadataUri: text("metadata_uri"),
  mintAddress: text("mint_address").notNull(),
  signature: text("signature").notNull(),
  walletAddress: text("wallet_address").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTokenSchema = createInsertSchema(tokens).omit({
  id: true,
  mintAddress: true,
  signature: true,
  walletAddress: true,
  createdAt: true,
});

export const createTokenSchema = insertTokenSchema.extend({
  name: z.string().min(1, "Token name is required").max(50, "Token name too long"),
  symbol: z.string().min(1, "Token symbol is required").max(10, "Token symbol too long").toUpperCase(),
  decimals: z.number().min(0).max(18).default(9),
  initialSupply: z.string().min(1, "Initial supply is required"),
  metadataUri: z.string().url("Invalid URL").optional().or(z.literal("")),
});

export type InsertToken = z.infer<typeof insertTokenSchema>;
export type CreateToken = z.infer<typeof createTokenSchema>;
export type Token = typeof tokens.$inferSelect;
